package com.kosta.lec;
/**
 * abstract		:    추상 (일반메서드(공통), 추상메서드(반드시각자구현))
 * interface	: 완전추상 (               추상메서드)
 * 
 * 추상클래스가 인터페이스를 상속받은 경우
 *   : 둘다 추상이기 때문에 반드시 오버라이딩 할 메서드는 없다 XXXX
 */
public    abstract class    Lec07인터페이스자식2  extends Lec07부모클래스
							                   implements 인터페이스부모1, 인터페이스부모2  {

	

}
