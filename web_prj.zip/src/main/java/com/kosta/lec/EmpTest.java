package com.kosta.lec;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class  EmpTest {
	public static void main(String[] args) {
		String str = "{\"mykey\",\"111\"}";
		//str.get("mykey")
		
		//{"mykey","111"}
		
	}
}