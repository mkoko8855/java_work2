//package com.kosta.lec;
//
//public class Test {
//
//	long add(int a, int b) {
//		return 0L;
//	}
//	
//	int add(char a, int b) {
//		System.out.println("dd");
//		return 0 * 10;
//	}
//	
//	
//	public static void main(String[] args) {
//		
//		boolean a = true;
//		int b = 3;
//		System.out.println(a+b);
//		
//	}
//
//
//}
